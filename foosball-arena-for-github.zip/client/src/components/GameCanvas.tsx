import { useEffect, useRef, useState } from "react";
import { Engine } from "@babylonjs/core/Engines/engine";
import { createGameScene, getTableMode, type GameHandle, type TableMode } from "@/game/scene";

const tableOptions: { id: TableMode; label: string; short: string }[] = [
  { id: "leonhart", label: "Leonhart ITSF", short: "01" },
  { id: "bonzini", label: "Bonzini Classic", short: "02" },
  { id: "tornado", label: "Tornado Power", short: "03" },
];

function tableUrl(id: TableMode) {
  const params = new URLSearchParams(window.location.search);
  params.set("table", id);
  return `${window.location.pathname}?${params.toString()}`;
}

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const startedRef = useRef(false);
  const [score, setScore] = useState({ left: 0, right: 0 });
  const [lastPoint, setLastPoint] = useState("READY");
  const table = getTableMode();
  const [hint, setHint] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || startedRef.current) return;
    startedRef.current = true;
    const engine = new Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true, adaptToDeviceRatio: true });
    let handle: GameHandle | null = null;
    let cancelled = false;
    createGameScene(engine, canvas).then((nextHandle) => {
      if (cancelled) { nextHandle.dispose(); return; }
      handle = nextHandle;
      engine.runRenderLoop(() => nextHandle.scene.render());
    });
    const onResize = () => engine.resize();
    const onScore = (event: Event) => {
      const detail = (event as CustomEvent<{ left: number; right: number; last: string }>).detail;
      setScore({ left: detail.left, right: detail.right });
      setLastPoint(detail.last);
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("foosball:score", onScore);
    const timer = window.setTimeout(() => setHint(false), 5400);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("foosball:score", onScore);
      handle?.dispose();
      engine.dispose();
      startedRef.current = false;
    };
  }, []);

  const reset = () => window.dispatchEvent(new CustomEvent("foosball:reset"));
  const kick = () => window.dispatchEvent(new CustomEvent("foosball:kick"));
  const rod = (delta: number) => window.dispatchEvent(new CustomEvent("foosball:rod", { detail: { delta } }));

  return (
    <main className="game-shell">
      <canvas ref={canvasRef} className="game-canvas" aria-label="Interactive 3D foosball table" style={{ touchAction: "none" }} />
      <div className="game-vignette" />
      <header className="topbar">
        <div className="brand-lockup"><span className="brand-mark">F</span><div><span className="eyebrow">FOOSBALL / LAB 04</span><strong>ARENA <em>+</em></strong></div></div>
        <div className="mode-lockup"><span className="eyebrow">LIVE SIMULATION</span><strong>TRAINING MODE</strong></div>
        <div className="top-actions"><span className="source-chip"><i /> SOURCE MESH • STL</span><button className="outline-btn" onClick={reset}>RESET <kbd>R</kbd></button></div>
      </header>

      <section className="scoreboard" aria-label="Scoreboard">
        <div className="score-team"><span className="team-dot cream" /><span>ALPHA</span><strong>{String(score.left).padStart(2, "0")}</strong></div>
        <div className="score-divider">:</div>
        <div className="score-team score-team-right"><strong>{String(score.right).padStart(2, "0")}</strong><span>BETA</span><span className="team-dot red" /></div>
      </section>

      <aside className="model-panel glass-panel">
        <div className="panel-kicker"><span>TABLE LAB</span><span className="panel-index">0{tableOptions.findIndex((item) => item.id === table) + 1} / 03</span></div>
        <h1>Change the<br /><span>table.</span></h1>
        <p>Switch between the Leonhart, Bonzini and Tornado presets. Each has its own figures, colors and cabinet.</p>
        <div className="model-list">{tableOptions.map((item) => <a key={item.id} href={tableUrl(item.id)} className={`model-option ${table === item.id ? "active" : ""}`}><span className="model-number">{item.short}</span><span>{item.label}</span><span className="model-arrow">{table === item.id ? "●" : "↗"}</span></a>)}</div>
        <div className="panel-foot"><span className="live-dot" /> {tableOptions.find((item) => item.id === table)?.label.toUpperCase()}</div>
      </aside>

      <div className="match-status"><span className="status-pulse" /> {lastPoint === "READY" ? "MATCH READY" : lastPoint} <span className="status-divider" /> BALL / {Math.round(42 + Math.abs(score.left - score.right) * 3)} KM/H</div>
      <div className={`hint ${hint ? "visible" : ""}`}><span>DRAG</span> orbit camera <span>•</span> <span>SPACE</span> kick ball <span>•</span> <span>W/S</span> move rod</div>
      <footer className="bottomline"><span>01</span><div className="line" /><span>FOOSBALL / TRAINING ARENA</span><div className="line" /><span>2026.09</span></footer>
      <button className="kick-button" onClick={kick} aria-label="Kick ball">KICK <span>↗</span></button>
      <div className="rod-controls"><button onClick={() => rod(0.2)}>＋</button><button onClick={() => rod(-0.2)}>－</button><span>ROD SHIFT</span></div>
    </main>
  );
}
